from django.apps import AppConfig


class FirstDjangoAppConfig(AppConfig):
    name = 'first_django_app'
