from django.urls import path, include

urlpatterns = [
    path('', include('dojo_ninjas_app.urls')),
]
